#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import os
from morai_msgs.msg import ObjectStatusList
from nav_msgs.msg import Odometry
from pyproj import Proj
from math import pi


class Person:
    def __init__(self, name, x, y):
        self.name = name
        self.lat = x
        self.lon = y

class getInform:
    def __init__(self):
        rospy.init_node('EGO_parser', anonymous=True)
        self.ego_0_sub = rospy.Subscriber("/Object_topic", ObjectStatusList, self.ego_0_callback)
        self.ego_2_sub = rospy.Subscriber("/ego_2/Object_topic", ObjectStatusList, self.ego_2_callback)


        # utm -> gps
        self.utm_proj = Proj(proj='utm', zone=52, ellps='WGS84', datum='WGS84', south=False)
        self.lonlat_proj = Proj(proj='latlong', ellps='WGS84', datum='WGS84')
        self.e_o = 302459.942
        self.n_o = 4122635.537

        # 초기화
        self.is_ego = False

        self.ego_list = ObjectStatusList()

        rate = rospy.Rate(30) # 30hz
        while not rospy.is_shutdown():
            if self.is_ego == True:

                os.system('clear')
                print("# ego name ")
                print(self.name)
                print("\n# ego x position ")
                print(self.x)
                print("\n# ego y position ")
                print(self.y)

                rate.sleep()

    def ego_0_callback(self, obj_0_list):

        for i in range(obj_0_list.num_of_npcs):
            
            self.name = obj_0_list.npc_list[i].name
            self.utm_x = obj_0_list.npc_list[i].position.x + self.e_o
            self.utm_y = obj_0_list.npc_list[i].position.y + self.n_o
            
            longitude, latitude = Proj.transform(self.utm_proj, self.lonlat_proj, self.utm_x, self.utm_y)

            temp = Person(self.name, longitude, latitude)
            print(temp)
            self.ego_list.append(temp)

        self.is_ego = True
        
    def ego_2_callback(self, obj_2_list):
        pass

if __name__ == '__main__':
    try:
        EGO_parser = getInform()
    except rospy.ROSInterruptException:
        pass
