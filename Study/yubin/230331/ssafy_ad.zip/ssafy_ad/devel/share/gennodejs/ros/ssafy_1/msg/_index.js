
"use strict";

let student = require('./student.js');

module.exports = {
  student: student,
};
