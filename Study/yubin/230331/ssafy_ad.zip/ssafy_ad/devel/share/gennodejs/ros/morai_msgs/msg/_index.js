
"use strict";

let RadarDetection = require('./RadarDetection.js');
let VehicleSpec = require('./VehicleSpec.js');
let ERP42Info = require('./ERP42Info.js');
let VehicleCollisionData = require('./VehicleCollisionData.js');
let MapSpecIndex = require('./MapSpecIndex.js');
let VehicleCollision = require('./VehicleCollision.js');
let EgoDdVehicleStatus = require('./EgoDdVehicleStatus.js');
let SetTrafficLight = require('./SetTrafficLight.js');
let DdCtrlCmd = require('./DdCtrlCmd.js');
let MoraiTLInfo = require('./MoraiTLInfo.js');
let TrafficLight = require('./TrafficLight.js');
let SyncModeCmd = require('./SyncModeCmd.js');
let ScenarioLoad = require('./ScenarioLoad.js');
let SyncModeInfo = require('./SyncModeInfo.js');
let ObjectStatusList = require('./ObjectStatusList.js');
let SyncModeResultResponse = require('./SyncModeResultResponse.js');
let Lamps = require('./Lamps.js');
let SyncModeRemoveObject = require('./SyncModeRemoveObject.js');
let WaitForTick = require('./WaitForTick.js');
let NpcGhostCmd = require('./NpcGhostCmd.js');
let IntscnTL = require('./IntscnTL.js');
let SaveSensorData = require('./SaveSensorData.js');
let MoraiTLIndex = require('./MoraiTLIndex.js');
let SyncModeScenarioLoad = require('./SyncModeScenarioLoad.js');
let CtrlCmd = require('./CtrlCmd.js');
let CollisionData = require('./CollisionData.js');
let GhostMessage = require('./GhostMessage.js');
let GPSMessage = require('./GPSMessage.js');
let SyncModeCtrlCmd = require('./SyncModeCtrlCmd.js');
let ReplayInfo = require('./ReplayInfo.js');
let EgoVehicleStatus = require('./EgoVehicleStatus.js');
let PREvent = require('./PREvent.js');
let IntersectionControl = require('./IntersectionControl.js');
let SensorPosControl = require('./SensorPosControl.js');
let ObjectStatus = require('./ObjectStatus.js');
let MapSpec = require('./MapSpec.js');
let NpcGhostInfo = require('./NpcGhostInfo.js');
let IntersectionStatus = require('./IntersectionStatus.js');
let MoraiSimProcHandle = require('./MoraiSimProcHandle.js');
let MoraiSrvResponse = require('./MoraiSrvResponse.js');
let SyncModeAddObject = require('./SyncModeAddObject.js');
let VehicleSpecIndex = require('./VehicleSpecIndex.js');
let WaitForTickResponse = require('./WaitForTickResponse.js');
let RadarDetections = require('./RadarDetections.js');
let SyncModeSetGear = require('./SyncModeSetGear.js');
let PRStatus = require('./PRStatus.js');
let GetTrafficLightStatus = require('./GetTrafficLightStatus.js');
let PRCtrlCmd = require('./PRCtrlCmd.js');
let MoraiSimProcStatus = require('./MoraiSimProcStatus.js');
let SyncModeCmdResponse = require('./SyncModeCmdResponse.js');
let MultiEgoSetting = require('./MultiEgoSetting.js');
let EventInfo = require('./EventInfo.js');

module.exports = {
  RadarDetection: RadarDetection,
  VehicleSpec: VehicleSpec,
  ERP42Info: ERP42Info,
  VehicleCollisionData: VehicleCollisionData,
  MapSpecIndex: MapSpecIndex,
  VehicleCollision: VehicleCollision,
  EgoDdVehicleStatus: EgoDdVehicleStatus,
  SetTrafficLight: SetTrafficLight,
  DdCtrlCmd: DdCtrlCmd,
  MoraiTLInfo: MoraiTLInfo,
  TrafficLight: TrafficLight,
  SyncModeCmd: SyncModeCmd,
  ScenarioLoad: ScenarioLoad,
  SyncModeInfo: SyncModeInfo,
  ObjectStatusList: ObjectStatusList,
  SyncModeResultResponse: SyncModeResultResponse,
  Lamps: Lamps,
  SyncModeRemoveObject: SyncModeRemoveObject,
  WaitForTick: WaitForTick,
  NpcGhostCmd: NpcGhostCmd,
  IntscnTL: IntscnTL,
  SaveSensorData: SaveSensorData,
  MoraiTLIndex: MoraiTLIndex,
  SyncModeScenarioLoad: SyncModeScenarioLoad,
  CtrlCmd: CtrlCmd,
  CollisionData: CollisionData,
  GhostMessage: GhostMessage,
  GPSMessage: GPSMessage,
  SyncModeCtrlCmd: SyncModeCtrlCmd,
  ReplayInfo: ReplayInfo,
  EgoVehicleStatus: EgoVehicleStatus,
  PREvent: PREvent,
  IntersectionControl: IntersectionControl,
  SensorPosControl: SensorPosControl,
  ObjectStatus: ObjectStatus,
  MapSpec: MapSpec,
  NpcGhostInfo: NpcGhostInfo,
  IntersectionStatus: IntersectionStatus,
  MoraiSimProcHandle: MoraiSimProcHandle,
  MoraiSrvResponse: MoraiSrvResponse,
  SyncModeAddObject: SyncModeAddObject,
  VehicleSpecIndex: VehicleSpecIndex,
  WaitForTickResponse: WaitForTickResponse,
  RadarDetections: RadarDetections,
  SyncModeSetGear: SyncModeSetGear,
  PRStatus: PRStatus,
  GetTrafficLightStatus: GetTrafficLightStatus,
  PRCtrlCmd: PRCtrlCmd,
  MoraiSimProcStatus: MoraiSimProcStatus,
  SyncModeCmdResponse: SyncModeCmdResponse,
  MultiEgoSetting: MultiEgoSetting,
  EventInfo: EventInfo,
};
